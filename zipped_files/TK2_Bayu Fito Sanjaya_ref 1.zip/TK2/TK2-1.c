#include <stdio.h>

int main()
{
    int hours;
    float price, discount, total;

    printf("Masukkan jumlah jam: ");
    /* The code block `if (scanf("%d", &hours) != 1)` is checking if the input provided by the user is
    a valid integer. */
    if (scanf("%d", &hours) != 1)
    {
        printf("Input bukan berupa angka.\n");
        return 1;
    }

    /* The code block provided a conditional statement that determines the price and discount based on the number of hours entered by the user.
        1. <= 4 : 0%
        2. <= 6 : 10%
        3. <= 8 : 15%
        4. <= 10 : 20%
        5. > 25%
    */
    price = hours * 10000;
    if (hours <= 4)
    {
        discount = 0;
    }
    else if (hours <= 6)
    {
        discount = 10;
    }
    else if (hours <= 8)
    {
        discount = 15;
    }
    else if (hours <= 10)
    {
        discount = 20;
    }
    else
    {
        discount = 25;
    }
    /* The line `total = price - (price * discount / 100);` is calculating the total amount that needs
    to be paid after applying the discount. */
    total = price - (price * discount / 100);
    printf("Lama pemakaian: %d jam\n", hours);
    printf("Harga: Rp %.2f\n", price);
    printf("Diskon: %d%%\n", (int)discount);
    printf("Total yang harus dibayarkan: Rp %.2f\n", total);
    return 0;
}
