#include <stdio.h>
#include <stdbool.h>
/**
 * Defines a data structure for storing information about students, including their name
 * and various scores.
 */
typedef struct
{
    char name[50];
    int quizScore;
    int assignmentScore;
    int attendanceScore;
    int practicalScore;
    int finalExamScore;
} Student;

// Function to calculate average
float calculateAverage(Student s)
{
    return (s.quizScore + s.assignmentScore + s.attendanceScore + s.practicalScore + s.finalExamScore) / 5.0;
}

// Function to determine grade
char calculateGrade(float score)
{
    if (score <= 55)
        return 'E';
    else if (score <= 65)
        return 'D';
    else if (score <= 75)
        return 'C';
    else if (score <= 85)
        return 'B';
    else
        return 'A';
}
// Function checks if a given number is between 10 and 100.
bool isValid(int number)
{
    return number >= 10 && number <= 100;
}

int main()
{
    Student students[10]; // Array to store student data
    printf("Harap masukan data dengan benar.\n");

    // Input student data
    for (int i = 0; i < 10; i++)
    {
        printf("===========================\n");
        printf("Masukkan data mahasiswa %d\n", i + 1);
        printf("Nama: ");
        scanf("%s", students[i].name);

        do
        {
            printf("Nilai Kuis: ");
            scanf("%d", &students[i].quizScore);
        } while (!isValid(students[i].quizScore));

        do
        {
            printf("Nilai Tugas: ");
            scanf("%d", &students[i].assignmentScore);
        } while (!isValid(students[i].assignmentScore));

        do
        {
            printf("Nilai Absensi: ");
            scanf("%d", &students[i].attendanceScore);
        } while (!isValid(students[i].attendanceScore));

        do
        {
            printf("Nilai Praktek: ");
            scanf("%d", &students[i].practicalScore);
        } while (!isValid(students[i].practicalScore));

        do
        {
            printf("Nilai UAS: ");
            scanf("%d", &students[i].finalExamScore);
        } while (!isValid(students[i].finalExamScore));

        printf("===========================\n");
    }

    // Calculate and display average and grade
    /* The code snippet `for (int i = 0; i < 10; i++) { ... }` is a loop that iterates over each
    student in the `students` array. */
    for (int i = 0; i < 10; i++)
    {
        float average = calculateAverage(students[i]);
        char grade = calculateGrade(average);
        printf("\nMahasiswa %s memiliki rata-rata: %.2f, dan grade: %c\n", students[i].name, average, grade);
        if (grade == 'D' || grade == 'E')
        {
            printf("Mahasiswa  %s Tidak Lulus\n", students[i].name);
        }
    }

    return 0;
}
