#include <stdio.h>

int main() {
    // Input lama pemakaian dalam jam
    float lama_pemakaian;
    printf("Masukkan lama pemakaian dalam jam: ");
    scanf("%f", &lama_pemakaian);

    // Harga per jam
    float harga_per_jam = 10000;

    // Inisialisasi diskon
    float diskon = 0;

    // Hitung diskon berdasarkan lama pemakaian
    if (lama_pemakaian > 8) {
        diskon = 0.25;  // Diskon 25% untuk pemakaian lebih dari 8 jam
    } else if (lama_pemakaian > 6) {
        diskon = 0.20;  // Diskon 20% untuk pemakaian lebih dari 6 jam
    } else if (lama_pemakaian > 4) {
        diskon = 0.15;  // Diskon 15% untuk pemakaian lebih dari 4 jam
    } else if (lama_pemakaian > 0) {
        diskon = 0.10;  // Diskon 10% untuk pemakaian lebih dari 0 jam
    }

    // Hitung total biaya
    float total_biaya = lama_pemakaian * harga_per_jam * (1 - diskon);

    // Cetak hasil
    printf("Total biaya yang harus dibayarkan: Rp %.2f\n", total_biaya);

    getchar();

    return 0;
}
