#include <stdio.h>

int main() {
    // Inisialisasi variabel untuk menyimpan jumlah mahasiswa dan total nilai
    int jumlah_mahasiswa = 10;
    float total_nilai = 0;
    int mahasiswa_tidak_lulus = 0;

    // Membuat array untuk menyimpan nilai-nilai mahasiswa
    float nilai_quis[10];
    float nilai_tugas[10];
    float nilai_absensi[10];
    float nilai_praktek[10];
    float nilai_uas[10];

    // Loop untuk menginput nilai dan menghitung total nilai
    for (int i = 0; i < jumlah_mahasiswa; i++) {
        printf("Masukkan nilai untuk Mahasiswa %d:\n", i + 1);
        printf("Nilai Quis: ");
        scanf("%f", &nilai_quis[i]);
        printf("Nilai Tugas: ");
        scanf("%f", &nilai_tugas[i]);
        printf("Nilai Absensi: ");
        scanf("%f", &nilai_absensi[i]);
        printf("Nilai Praktek: ");
        scanf("%f", &nilai_praktek[i]);
        printf("Nilai UAS: ");
        scanf("%f", &nilai_uas[i]);

        // Menghitung rata-rata nilai mahasiswa
        float nilai_rata_rata =
                (nilai_quis[i] + nilai_tugas[i] + nilai_absensi[i] + nilai_praktek[i] + nilai_uas[i]) / 5;

        // Menambahkan nilai rata-rata ke total nilai
        total_nilai += nilai_rata_rata;

        // Menentukan grade
        char grade;
        if (nilai_rata_rata <= 55) {
            grade = 'E';
            mahasiswa_tidak_lulus++;
        } else if (nilai_rata_rata <= 65) {
            grade = 'D';
            mahasiswa_tidak_lulus++;
        } else if (nilai_rata_rata <= 75) {
            grade = 'C';
        } else if (nilai_rata_rata <= 85) {
            grade = 'B';
        } else {
            grade = 'A';
        }

        // Menampilkan hasil grade
        printf("Grade: %c\n\n", grade);
    }

    // Menghitung rata-rata nilai seluruh mahasiswa
    float rata_rata_total = total_nilai / jumlah_mahasiswa;

    // Menampilkan rata-rata nilai seluruh mahasiswa
    printf("Rata-rata nilai seluruh mahasiswa: %.2f\n", rata_rata_total);

    // Menampilkan status kelulusan
    if (mahasiswa_tidak_lulus > 0) {
        printf("Status: Tidak Lulus\n");
    } else {
        printf("Status: Lulus\n");
    }

    getchar();

    return 0;
}
